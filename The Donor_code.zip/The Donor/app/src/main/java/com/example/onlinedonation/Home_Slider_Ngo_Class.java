package com.example.onlinedonation;

public class Home_Slider_Ngo_Class {
    private int Ngo_Logo;
    private String Ngo_Name;

    public void setNgo_Logo(int ngo_Logo) {
        Ngo_Logo = ngo_Logo;
    }

    public void setNgo_Name(String ngo_Name) {
        Ngo_Name = ngo_Name;
    }

    public int getNgo_Logo() {
        return Ngo_Logo;
    }

    public String getNgo_Name() {
        return Ngo_Name;
    }
}
