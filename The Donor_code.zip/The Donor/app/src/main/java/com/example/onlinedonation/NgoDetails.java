package com.example.onlinedonation;

public class NgoDetails {
    String NgoName;
    String NgoLocation;
    int NgoImage;

    public String getNgoName() {
        return NgoName;
    }

    public String getNgoLocation() {
        return NgoLocation;
    }

    public int getNgoImage() {
        return NgoImage;
    }

    public void setNgoName(String ngoName) {
        NgoName = ngoName;
    }

    public void setNgoLocation(String ngoLocation) {
        NgoLocation = ngoLocation;
    }

    public void setNgoImage(int ngoImage) {
        NgoImage = ngoImage;
    }
}
