package com.example.onlinedonation;

public class SliderClass {


    int imageId;

    public void setImageId(int imageId) {
        this.imageId = imageId;
    }

    public int getImageId() {
        return imageId;
    }
}
