package com.example.onlinedonation;

public class UserNgoRequest {

    String name;
    String city;
    String image;
    String mobile;
    String item;
    String donor;


    public void setDonor(String donor) {
        this.donor = donor;
    }

    public String getDonor() {
        return donor;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public String getItem() {
        return item;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getMobile() {
        return mobile;
    }

    String desc;
    String time;
    String email;

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEmail() {
        return email;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getTime() {
        return time;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getName() {
        return name;
    }

    public String getCity() {
        return city;
    }

    public String getImage() {
        return image;
    }

    public String getDesc() {
        return desc;
    }
}
