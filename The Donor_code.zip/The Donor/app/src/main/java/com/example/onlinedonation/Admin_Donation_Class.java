package com.example.onlinedonation;

public class Admin_Donation_Class {

    String image;
    String desc;
    String city;
    String email;
    String id;
    String item;
    String mobile;
    String name;

    public void setImage(String image) {
        this.image = image;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImage() {
        return image;
    }

    public String getDesc() {
        return desc;
    }

    public String getCity() {
        return city;
    }

    public String getEmail() {
        return email;
    }

    public String getId() {
        return id;
    }

    public String getItem() {
        return item;
    }

    public String getMobile() {
        return mobile;
    }

    public String getName() {
        return name;
    }
}
