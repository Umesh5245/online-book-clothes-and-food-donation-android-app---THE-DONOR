package com.example.onlinedonation;

public class UserDashboardClass {


    String name;
    String desc;
    String time;

    public void setName(String name) {
        this.name = name;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getName() {
        return name;
    }

    public String getDesc() {
        return desc;
    }

    public String getTime() {
        return time;
    }
}
