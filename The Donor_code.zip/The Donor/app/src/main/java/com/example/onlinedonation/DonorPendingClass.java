package com.example.onlinedonation;

public class DonorPendingClass {


    String msg;
    String desc;
    String time;

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getMsg() {
        return msg;
    }

    public String getDesc() {
        return desc;
    }

    public String getTime() {
        return time;
    }



}
