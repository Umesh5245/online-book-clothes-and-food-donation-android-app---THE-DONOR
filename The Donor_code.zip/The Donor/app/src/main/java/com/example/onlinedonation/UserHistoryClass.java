package com.example.onlinedonation;

public class UserHistoryClass {
    String desc;
    String donor;
    String ngo;
    String time;

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public void setDonor(String donor) {
        this.donor = donor;
    }

    public void setNgo(String ngo) {
        this.ngo = ngo;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getDesc() {
        return desc;
    }

    public String getDonor() {
        return donor;
    }

    public String getNgo() {
        return ngo;
    }

    public String getTime() {
        return time;
    }
}
