package com.example.onlinedonation;

public class Home_Slider_Class {
    String image;
    String name;
    String location;
    String ngo;

    public void setImage(String image) {
        this.image = image;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setNgo(String ngo) {
        this.ngo = ngo;
    }

    public String getImage() {
        return image;
    }

    public String getName() {
        return name;
    }

    public String getLocation() {
        return location;
    }

    public String getNgo() {
        return ngo;
    }
}
